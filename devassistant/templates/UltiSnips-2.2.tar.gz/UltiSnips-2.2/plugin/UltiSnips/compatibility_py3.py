#!/usr/bin/env python
# encoding: utf-8


"""
This file contains code that is invalid in python2 and must therefore never be
seen by the interpretor
"""

compatible_exec = exec
